var config = {
    map: {
        '*': {
            'mw-review-modal': 'MageWorx_Info/js/mw-review-modal'
        }
    }
};